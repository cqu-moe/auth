# ✗ school binding persists and returns an allowed business directory through the real container

`e2e/school/journey.school.ts` · failed · 1.4s

Ran on: browser `chromium 156.0.8078.4` · user agent `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/156.0.8078.4 Safari/537.36`

**ASSERTION_FAILED**

```text
expect.toHaveText failed
locator: getByRole("heading", name: "欢迎回来")
expected: text "故意错误的学校绑定入口"
observed: text "欢迎回来" (match count 1)
```

Look at: `e2e/school/journey.school.ts:64`  

## Steps

1. ✓ `browser.route` `**/*` (3ms in beforeEach) — `e2e/school/journey.school.ts:11`
2. ✓ `app.open` `/login` (164ms) — `e2e/school/journey.school.ts:62`
   - ↪ navigated to /login
   - screen: 18 nodes at `/login`
3. ✗ `expect.toHaveText` `getByRole("heading", name: "欢迎回来")` (1.0s) — **ASSERTION_FAILED** — `e2e/school/journey.school.ts:64`
   - expect gave up after 10 reads in 1.0s: text "欢迎回来" (1 match) x10

## Screen at failure

`http://localhost:51559/login` · viewport 390x844 · 18 nodes  

![screenshot at failure](attempt-1/screenshots/001-failure.png)

The screen as the agent reads it, one node per line: `#id role "name" text="…" [states]`.

```text
#root document "CQU Auth"
 #n2 banner
  #n3 link "CQU Auth" href="/login"
  #n4 button "外观设置"
 #n5 main
  #n6 heading "欢迎回来"
  #n7 text="登录你的账户，继续使用校园服务。"
  #n8 text="邮箱"
  #n9 textbox "邮箱"
  #n10 text="密码"
  #n11 link "忘记密码？" href="/reset-password"
  #n12 textbox "密码" value=<secure> purpose=password [secure]
  #n13 button "登录"
  #n14 status
  #n15 button "使用 Passkey 登录"
  #n16 text="还没有账户？ 立即注册"
   #n17 link "立即注册" href="/register"
 #n18 contentinfo text="CQU Auth 重庆大学统一认证"
```

## Evidence

- [screenshot](attempt-1/screenshots/001-failure.png) `.e2e/school-negative-1792087862645/assertion/mobile/results/journey-school-school-binding-persists-and-e2276b307c2e9f84/attempt-1/screenshots/001-failure.png`
- [screen](attempt-1/screen-at-failure.txt) `.e2e/school-negative-1792087862645/assertion/mobile/results/journey-school-school-binding-persists-and-e2276b307c2e9f84/attempt-1/screen-at-failure.txt`

<sub>e2e 0.21.0 · run `01a140c2-c385-71c7-b3c2-e8124b6d1142` · the whole run is in `report.json`</sub>
